// src/app.ts
import express from 'express';
import playerRoutes from './routes/playerRoutes';

const app = express();

app.use(express.json());
app.use('/api', playerRoutes);

export default app;
