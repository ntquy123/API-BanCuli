// src/controllers/playerController.ts
import { Request, Response } from 'express';
import { getPlayer, updatePlayerExperience, levelUpPlayer } from '../services/playerService';

export const getPlayerController = async (req: Request, res: Response) => {
  try {
    const playerId = parseInt(req.params.id);
    const player = await getPlayer(playerId);
    if (player) {
      res.json(player);
    } else {
      res.status(404).json({ message: 'Player not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateExperienceController = async (req: Request, res: Response) => {
  try {
    const playerId = parseInt(req.params.id);
    const { experience } = req.body;
    const updatedPlayer = await updatePlayerExperience(playerId, experience);
    res.json(updatedPlayer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const levelUpController = async (req: Request, res: Response) => {
  try {
    const playerId = parseInt(req.params.id);
    const updatedPlayer = await levelUpPlayer(playerId);
    if (updatedPlayer) {
      res.json(updatedPlayer);
    } else {
      res.status(404).json({ message: 'Player not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
