// src/services/playerService.ts
import prisma from '../models/prismaClient'; // Import Prisma Client

export const getPlayer = async (playerId: number) => {
  return await prisma.player.findUnique({
    where: { id: playerId },
  });
};

export const updatePlayerExperience = async (playerId: number, experience: number) => {
  return await prisma.player.update({
    where: { id: playerId },
    data: { experience },
  });
};

export const levelUpPlayer = async (playerId: number) => {
  const player = await prisma.player.findUnique({
    where: { id: playerId },
  });

  if (player) {
    const newLevel = Math.floor(player.experience / 1000) + 1; // Assume level-up after 1000 experience
    return await prisma.player.update({
      where: { id: playerId },
      data: { level: newLevel },
    });
  }

  return null;
};
