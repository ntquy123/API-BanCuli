// src/models/prismaClient.ts
import { PrismaClient } from '@prisma/client';

// Khởi tạo Prisma Client
const prisma = new PrismaClient();

// Export Prisma Client để sử dụng trong các file khác
export default prisma;
