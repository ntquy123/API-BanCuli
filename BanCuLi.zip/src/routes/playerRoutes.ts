// src/routes/playerRoutes.ts
import { Router } from 'express';
import { getPlayerController, updateExperienceController, levelUpController } from '../controllers/playerController';

const router = Router();

router.get('/player/:id', getPlayerController);
router.post('/player/:id/experience', updateExperienceController);
router.post('/player/:id/level-up', levelUpController);

export default router;
